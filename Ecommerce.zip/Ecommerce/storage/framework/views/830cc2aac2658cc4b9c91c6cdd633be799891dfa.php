<div class="form-group">
    <label class="control-label">Icon 1</label>
    <input type="text" name="icon1" data-shortcode-attribute="icon1" class="form-control" placeholder="Icon 1">
</div>

<div class="form-group">
    <label class="control-label">Title 1</label>
    <input type="text" name="title1" data-shortcode-attribute="title1" class="form-control" placeholder="Title 1">
</div>

<div class="form-group">
    <label class="control-label">Description 1</label>
    <input type="text" name="description1" data-shortcode-attribute="description1" class="form-control"
           placeholder="Description 1">
</div>

<div class="form-group">
    <label class="control-label">Icon 2</label>
    <input type="text" name="icon2" data-shortcode-attribute="icon2" class="form-control" placeholder="Icon 2">
</div>

<div class="form-group">
    <label class="control-label">Title 2</label>
    <input type="text" name="title2" data-shortcode-attribute="title2" class="form-control" placeholder="Title 2">
</div>

<div class="form-group">
    <label class="control-label">Description 2</label>
    <input type="text" name="description2" data-shortcode-attribute="description2" class="form-control"
           placeholder="Description 2">
</div>

<div class="form-group">
    <label class="control-label">Icon 3</label>
    <input type="text" name="icon3" data-shortcode-attribute="icon3" class="form-control" placeholder="Icon 3">
</div>

<div class="form-group">
    <label class="control-label">Title 3</label>
    <input type="text" name="title3" data-shortcode-attribute="title3" class="form-control" placeholder="Title 3">
</div>

<div class="form-group">
    <label class="control-label">Description 3</label>
    <input type="text" name="description3" data-shortcode-attribute="description3" class="form-control"
           placeholder="Description 3">
</div>
<?php /**PATH /Users/mac/workspace/shopwise/platform/themes/shopwise/partials/shortcodes/our-features-admin-config.blade.php ENDPATH**/ ?>