<div class="form-group">
    <label class="control-label">Youtube URL</label>
    <input name="url" data-shortcode-attribute="content" class="form-control" placeholder="https://www.youtube.com/watch?v=FN7ALfpGxiI">
</div>
<?php /**PATH /Users/mac/workspace/shopwise/platform/themes/shopwise/partials/shortcodes/youtube-video-admin-config.blade.php ENDPATH**/ ?>